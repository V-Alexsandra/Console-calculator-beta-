﻿using System;
using System.Collections.Generic;

namespace Сalculator
{
    class Calculator
    {
        public static string[] strmas = new string[100];
        public static List<double> chisla = new List<double>();
        public static double res;

        public static string[] vvod()
        {
            string str;
            Console.WriteLine("Введите выражение, закончив его точкой. \nВводить числа и " +
            "арифметические операции нужно через пробел, по приоритету и без скобок");
            str = Console.ReadLine();
            Calculator.strmas = str.Split(' ');
            return Calculator.strmas;
        }
        public static List<double> mas()
        {
            chisla.Add(Convert.ToDouble(strmas[0]));
            res = chisla[0];
            for (int i = 1; i < strmas.Length; i++)
            {
                for (int j = 1; j <= chisla.Count; j++)
                {
                    try
                    {
                        chisla.Add(Convert.ToDouble(strmas[i]));
                    }
                    catch
                    {
                        j--;
                    }
                    break;
                }
            }
            return chisla;
        }
        public static double resh()
        {
            int j, f=1;
            for(int i=0; i<strmas.Length; i++ )
            { 
                for (j = f; j < chisla.Count; j++)
                {
                    if (strmas[i] == "+")
                    {
                        res += chisla[j];
                        f++;
                    }
                    else if (strmas[i] == "-")
                    {
                        res -= chisla[j];
                        f++;
                    }
                    else if (strmas[i] == "/")
                    {
                        res /= chisla[j];
                        f++;
                    }
                    else if (strmas[i] == "*")
                    {
                        res *= chisla[j];
                        f++;
                    }
                    break;
                }
            }
            return res;
        }
    }
}
