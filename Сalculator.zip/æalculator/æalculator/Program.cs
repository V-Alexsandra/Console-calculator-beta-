﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Сalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator.vvod();
            Console.WriteLine("Введенное выражение: ");
            foreach(string s in Calculator.strmas)
                Console.Write(s);
            Console.Write("=");
            Calculator.mas();
            Console.Write(Calculator.resh());
            Console.ReadKey();
        }
    }
}
